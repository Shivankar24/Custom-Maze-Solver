Instructions to run:-
Python sdmaze.py <mazefile>

Output:-
1)Each run for a puzzle will print the output for three heuristics in the order Heuristic 1,2 and 3
2)Each heuristic output would display the count for nodes visited , nodes generated and the number of steps to reach the goal.
3)Then the output follows the route to trace on the the maze with the die in each state and moves taken.
4)Output is displayed if there is any solution else displays no solution.
5)At each step, the position of the die is shown in the output maze by 'D'. 
6)Each step also shows the die configuration by depciting the TOP, FRONT and RIGHT values on the face of 
the die after making each move. 